import mongoose from "mongoose";

const enquirySchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, minlength: 2, maxlength: 100 },
  email: { type: String, required: true, trim: true, lowercase: true, match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/ },
  phone: { type: String, required: true, trim: true, match: /^[0-9+\-\s()]{7,20}$/ },
  message: { type: String, required: true, trim: true, minlength: 5, maxlength: 1000 },
  propertyId: { type: mongoose.Schema.Types.ObjectId, ref: "Property", default: null }
}, { timestamps: true });

export default mongoose.model("Enquiry", enquirySchema);
