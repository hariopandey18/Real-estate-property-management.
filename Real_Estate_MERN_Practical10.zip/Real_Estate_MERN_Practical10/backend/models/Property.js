import mongoose from "mongoose";

const propertySchema = new mongoose.Schema({
  title: { type: String, required: [true, "Title is required"], trim: true, minlength: 3, maxlength: 100 },
  description: { type: String, required: [true, "Description is required"], trim: true, minlength: 10, maxlength: 1500 },
  location: { type: String, required: [true, "Location is required"], trim: true, minlength: 2, maxlength: 120 },
  price: { type: Number, required: true, min: [1, "Price must be positive"] },
  type: { type: String, enum: ["Apartment", "Villa", "Plot", "Commercial"], required: true },
  bhk: { type: Number, min: 0, max: 20, default: 1 },
  areaSqFt: { type: Number, min: 1, required: true },
  status: { type: String, enum: ["Available", "Under Offer", "Sold"], default: "Available" },
  imageUrl: { type: String, trim: true, default: "" },
  ownerName: { type: String, trim: true, maxlength: 100, default: "" }
}, { timestamps: true });

export default mongoose.model("Property", propertySchema);
