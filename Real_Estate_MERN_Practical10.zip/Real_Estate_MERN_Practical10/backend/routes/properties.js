import { Router } from "express";
import mongoose from "mongoose";
import Property from "../models/Property.js";
import { validateProperty } from "../utils/validateProperty.js";

const router = Router();

router.get("/", async (req, res, next) => {
  try {
    const { search = "", type = "", status = "" } = req.query;
    const filter = {};
    if (type) filter.type = type;
    if (status) filter.status = status;
    if (search) filter.$or = [
      { title: { $regex: search, $options: "i" } },
      { location: { $regex: search, $options: "i" } }
    ];
    const properties = await Property.find(filter).sort({ createdAt: -1 });
    res.json({ success: true, count: properties.length, data: properties });
  } catch (err) { next(err); }
});

router.get("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid property ID." });
    const property = await Property.findById(req.params.id);
    if (!property) return res.status(404).json({ success: false, message: "Property not found." });
    res.json({ success: true, data: property });
  } catch (err) { next(err); }
});

router.post("/", async (req, res, next) => {
  try {
    const errors = validateProperty(req.body);
    if (Object.keys(errors).length) return res.status(400).json({ success: false, message: "Please correct the form.", errors });
    const property = await Property.create(req.body);
    res.status(201).json({ success: true, message: "Property created.", data: property });
  } catch (err) { next(err); }
});

router.put("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid property ID." });
    const errors = validateProperty(req.body);
    if (Object.keys(errors).length) return res.status(400).json({ success: false, message: "Please correct the form.", errors });
    const property = await Property.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!property) return res.status(404).json({ success: false, message: "Property not found." });
    res.json({ success: true, message: "Property updated.", data: property });
  } catch (err) { next(err); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ success: false, message: "Invalid property ID." });
    const property = await Property.findByIdAndDelete(req.params.id);
    if (!property) return res.status(404).json({ success: false, message: "Property not found." });
    res.json({ success: true, message: "Property deleted." });
  } catch (err) { next(err); }
});

export default router;
