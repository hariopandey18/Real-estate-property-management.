import { Router } from "express";
import mongoose from "mongoose";
import Enquiry from "../models/Enquiry.js";
import Property from "../models/Property.js";

const router = Router();

router.get("/", async (_req, res, next) => {
  try {
    const data = await Enquiry.find().populate("propertyId", "title location").sort({ createdAt: -1 });
    res.json({ success: true, count: data.length, data });
  } catch (err) { next(err); }
});

router.post("/", async (req, res, next) => {
  try {
    const { name, email, phone, message, propertyId } = req.body;
    const errors = {};
    if (!name || name.trim().length < 2) errors.name = "Name must contain at least 2 characters.";
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.email = "Enter a valid email.";
    if (!phone || !/^[0-9+\-\s()]{7,20}$/.test(phone)) errors.phone = "Enter a valid phone number.";
    if (!message || message.trim().length < 5) errors.message = "Message must contain at least 5 characters.";
    if (propertyId && !mongoose.isValidObjectId(propertyId)) errors.propertyId = "Invalid property.";
    if (Object.keys(errors).length) return res.status(400).json({ success: false, message: "Please correct the form.", errors });
    if (propertyId && !(await Property.exists({ _id: propertyId }))) return res.status(404).json({ success: false, message: "Selected property not found." });
    const enquiry = await Enquiry.create({ name, email, phone, message, propertyId: propertyId || null });
    res.status(201).json({ success: true, message: "Enquiry submitted.", data: enquiry });
  } catch (err) { next(err); }
});

export default router;
