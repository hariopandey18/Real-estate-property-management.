const allowedTypes = ["Apartment", "Villa", "Plot", "Commercial"];
const allowedStatuses = ["Available", "Under Offer", "Sold"];

export function validateProperty(body) {
  const errors = {};
  if (!body.title || body.title.trim().length < 3) errors.title = "Title must be at least 3 characters.";
  if (!body.description || body.description.trim().length < 10) errors.description = "Description must be at least 10 characters.";
  if (!body.location || body.location.trim().length < 2) errors.location = "Location is required.";
  if (!Number.isFinite(Number(body.price)) || Number(body.price) <= 0) errors.price = "Enter a price greater than zero.";
  if (!allowedTypes.includes(body.type)) errors.type = "Select a valid property type.";
  if (!Number.isFinite(Number(body.areaSqFt)) || Number(body.areaSqFt) <= 0) errors.areaSqFt = "Area must be greater than zero.";
  if (body.bhk !== "" && body.bhk !== undefined && (!Number.isFinite(Number(body.bhk)) || Number(body.bhk) < 0 || Number(body.bhk) > 20)) errors.bhk = "BHK must be between 0 and 20.";
  if (body.status && !allowedStatuses.includes(body.status)) errors.status = "Select a valid status.";
  if (body.imageUrl && !/^https?:\/\/.+/i.test(body.imageUrl)) errors.imageUrl = "Image URL must start with http:// or https://.";
  return errors;
}
