import { useEffect, useMemo, useState } from "react";
import { Building2, Search, Plus, MapPin, BedDouble, Maximize, ArrowUpRight, Pencil, Trash2, X, Home, MessageSquare, CheckCircle2, Menu } from "lucide-react";
import { request } from "./api";

const sampleProperties = [
  { _id: "demo1", title: "Serene Heights Residence", description: "Bright and airy home with a practical layout, modern kitchen and excellent connectivity.", location: "Mira Road, Mumbai", price: 7850000, type: "Apartment", bhk: 2, areaSqFt: 890, status: "Available", imageUrl: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80", ownerName: "Demo Owner" },
  { _id: "demo2", title: "Palm Grove Villa", description: "A spacious family villa with outdoor space, natural light and a peaceful neighbourhood.", location: "Vasai West, Palghar", price: 14200000, type: "Villa", bhk: 3, areaSqFt: 1850, status: "Available", imageUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80", ownerName: "Demo Owner" },
  { _id: "demo3", title: "Urban Nest Apartment", description: "Smartly planned apartment near daily essentials, transport links and local shopping.", location: "Virar East, Palghar", price: 4650000, type: "Apartment", bhk: 1, areaSqFt: 620, status: "Under Offer", imageUrl: "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1200&q=80", ownerName: "Demo Owner" },
  { _id: "demo4", title: "Greenfield Development Plot", description: "Open plot for a future home or long-term planning. Verify title and permissions before purchase.", location: "Nalasopara East, Palghar", price: 3200000, type: "Plot", bhk: 0, areaSqFt: 1200, status: "Available", imageUrl: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80", ownerName: "Demo Owner" }
];

const emptyForm = { title: "", description: "", location: "", price: "", type: "Apartment", bhk: "1", areaSqFt: "", status: "Available", imageUrl: "", ownerName: "" };
const money = n => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(Number(n || 0));
const initialErrors = {};
function App() {
  const [properties, setProperties] = useState(sampleProperties);
  const [enquiries, setEnquiries] = useState([]);
  const [demoMode, setDemoMode] = useState(false);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [activeTab, setActiveTab] = useState("properties");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState(initialErrors);
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(true);
  const [enquiryForm, setEnquiryForm] = useState({ name: "", email: "", phone: "", message: "", propertyId: "" });
  const [showEnquiry, setShowEnquiry] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);

  async function loadProperties() {
    try {
      const result = await request("/properties");
      setProperties(result.data);
      setDemoMode(false);
    } catch {
      setProperties(sampleProperties);
      setDemoMode(true);
    } finally { setLoading(false); }
  }
  async function loadEnquiries() {
    try { const result = await request("/enquiries"); setEnquiries(result.data); }
    catch { /* Backend may be offline while previewing the frontend. */ }
  }
  useEffect(() => { loadProperties(); loadEnquiries(); }, []);

  const filtered = useMemo(() => properties.filter(p => {
    const q = search.toLowerCase();
    return (!q || `${p.title} ${p.location} ${p.description}`.toLowerCase().includes(q))
      && (typeFilter === "All" || p.type === typeFilter)
      && (statusFilter === "All" || p.status === statusFilter);
  }), [properties, search, typeFilter, statusFilter]);

  function openAdd() { setEditing(null); setForm(emptyForm); setErrors({}); setShowForm(true); }
  function openEdit(p) { setEditing(p); setForm({ ...emptyForm, ...p, price: String(p.price), bhk: String(p.bhk ?? 1), areaSqFt: String(p.areaSqFt) }); setErrors({}); setShowForm(true); }
  function validate() {
    const e = {};
    if (form.title.trim().length < 3) e.title = "Enter at least 3 characters.";
    if (form.description.trim().length < 10) e.description = "Enter at least 10 characters.";
    if (form.location.trim().length < 2) e.location = "Location is required.";
    if (!form.price || Number(form.price) <= 0) e.price = "Enter a price greater than zero.";
    if (!form.areaSqFt || Number(form.areaSqFt) <= 0) e.areaSqFt = "Enter a valid area.";
    if (form.imageUrl && !/^https?:\/\/.+/i.test(form.imageUrl)) e.imageUrl = "Use a valid http/https image URL.";
    setErrors(e); return Object.keys(e).length === 0;
  }
  async function saveProperty(e) {
    e.preventDefault();
    if (!validate()) return;
    const payload = { ...form, price: Number(form.price), bhk: Number(form.bhk || 0), areaSqFt: Number(form.areaSqFt) };
    try {
      if (demoMode) {
        if (editing) setProperties(prev => prev.map(p => p._id === editing._id ? { ...payload, _id: editing._id } : p));
        else setProperties(prev => [{ ...payload, _id: `demo-${Date.now()}` }, ...prev]);
        setNotice("Saved in demo mode. Connect the backend to store changes permanently.");
      } else {
        const result = await request(editing ? `/properties/${editing._id}` : "/properties", { method: editing ? "PUT" : "POST", body: JSON.stringify(payload) });
        setNotice(result.message); await loadProperties();
      }
      setShowForm(false);
    } catch (err) { setErrors(err.details || {}); setNotice(err.message); }
  }
  async function deleteProperty(p) {
    if (!window.confirm(`Delete "${p.title}"?`)) return;
    try {
      if (demoMode || String(p._id).startsWith("demo")) setProperties(prev => prev.filter(item => item._id !== p._id));
      else { const result = await request(`/properties/${p._id}`, { method: "DELETE" }); setNotice(result.message); await loadProperties(); }
      setNotice(demoMode ? "Removed from demo view. Connect the backend for permanent changes." : "Property deleted.");
    } catch (err) { setNotice(err.message); }
  }
  async function submitEnquiry(e) {
    e.preventDefault();
    if (enquiryForm.name.trim().length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(enquiryForm.email) || !/^[0-9+\-\s()]{7,20}$/.test(enquiryForm.phone) || enquiryForm.message.trim().length < 5) {
      setNotice("Please check your name, email, phone and message."); return;
    }
    try {
      if (demoMode) setEnquiries(prev => [{ ...enquiryForm, _id: `demo-${Date.now()}`, createdAt: new Date().toISOString() }, ...prev]);
      else { await request("/enquiries", { method: "POST", body: JSON.stringify({ ...enquiryForm, propertyId: enquiryForm.propertyId || null }) }); await loadEnquiries(); }
      setNotice("Enquiry submitted successfully."); setShowEnquiry(false); setEnquiryForm({ name: "", email: "", phone: "", message: "", propertyId: "" });
    } catch (err) { setNotice(err.message); }
  }

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" onClick={e => { e.preventDefault(); setActiveTab("properties"); }}><span className="brand-mark"><Building2 size={22}/></span><span>estate<span className="brand-light">flow</span><small>PROPERTY MANAGEMENT</small></span></a>
      <button className="mobile-menu" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Toggle menu"><Menu/></button>
      <nav className={mobileMenu ? "nav open" : "nav"}>
        <button className={activeTab === "properties" ? "nav-link active" : "nav-link"} onClick={() => { setActiveTab("properties"); setMobileMenu(false); }}><Home size={16}/> Properties</button>
        <button className={activeTab === "enquiries" ? "nav-link active" : "nav-link"} onClick={() => { setActiveTab("enquiries"); setMobileMenu(false); }}><MessageSquare size={16}/> Enquiries <span className="nav-count">{enquiries.length}</span></button>
      </nav>
      <button className="btn btn-dark top-add" onClick={openAdd}><Plus size={17}/> Add property</button>
    </header>

    <main>
      <section className="hero">
        <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-line"></span> YOUR PROPERTY, ORGANIZED</div><h1>Find a place<br/>to <em>belong.</em></h1><p>Manage listings, discover spaces, and keep every property detail in one place.</p><div className="hero-actions"><button className="btn btn-lime" onClick={openAdd}><Plus size={17}/> List a property</button><button className="text-action" onClick={() => document.getElementById("listing-section")?.scrollIntoView({ behavior: "smooth" })}>Explore listings <ArrowUpRight size={16}/></button></div><div className="hero-trust"><span className="trust-dot"></span> A smarter way to manage real estate</div></div>
        <div className="hero-visual"><img src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1400&q=85" alt="Modern sunlit living room"/><div className="hero-image-label"><span>CURATED SPACES</span><strong>Spaces for your next chapter.</strong></div><div className="floating-card"><span className="float-icon"><Building2 size={18}/></span><div><strong>{properties.length.toString().padStart(2, "0")} properties</strong><small>in your workspace</small></div><span className="float-arrow"><ArrowUpRight size={17}/></span></div><div className="hero-vertical">ESTATEFLOW · PROPERTY DIRECTORY</div></div>
      </section>

      <section className="stats-row">
        <div className="stat"><span className="stat-icon"><Building2 size={18}/></span><div><strong>{properties.length}</strong><span>Total properties</span></div></div>
        <div className="stat"><span className="stat-icon"><CheckCircle2 size={18}/></span><div><strong>{properties.filter(p => p.status === "Available").length}</strong><span>Available now</span></div></div>
        <div className="stat"><span className="stat-icon"><MessageSquare size={18}/></span><div><strong>{enquiries.length}</strong><span>Customer enquiries</span></div></div>
        <div className="stat stat-note"><span>MADE FOR BETTER<br/>PROPERTY DECISIONS</span><ArrowUpRight size={19}/></div>
      </section>

      {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss"><X size={16}/></button></div>}
      {demoMode && <div className="demo-banner"><span className="demo-dot"></span><strong>Preview mode</strong> — sample listings are displayed because the API is unavailable. Add MongoDB and start the backend to save data permanently.</div>}

      {activeTab === "properties" ? <section className="listing-section" id="listing-section">
        <div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"></span> THE COLLECTION</div><h2>Explore <em>properties.</em></h2><p>Thoughtfully selected spaces for every kind of next step.</p></div><button className="btn btn-outline" onClick={openAdd}><Plus size={17}/> Add new listing</button></div>
        <div className="filter-bar"><div className="searchbox"><Search size={18}/><input aria-label="Search properties" placeholder="Search by property or location..." value={search} onChange={e => setSearch(e.target.value)}/>{search && <button onClick={() => setSearch("")}><X size={15}/></button>}</div><select aria-label="Filter by property type" value={typeFilter} onChange={e => setTypeFilter(e.target.value)}><option>All</option><option>Apartment</option><option>Villa</option><option>Plot</option><option>Commercial</option></select><select aria-label="Filter by status" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}><option>All</option><option>Available</option><option>Under Offer</option><option>Sold</option></select><span className="result-count">{filtered.length} RESULTS</span></div>
        {loading ? <div className="empty-state">Loading properties…</div> : filtered.length ? <div className="property-grid">{filtered.map((p, i) => <article className="property-card" key={p._id}><div className="property-image"><img src={p.imageUrl || "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=900&q=80"} alt={p.title} onError={e => { e.currentTarget.src = "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=900&q=80"; }}/><span className={`status-badge ${p.status === "Available" ? "available" : p.status === "Sold" ? "sold" : "offer"}`}>{p.status}</span><button className="image-open" title="View details" onClick={() => { setEnquiryForm(prev => ({ ...prev, propertyId: String(p._id).startsWith("demo") ? "" : p._id, message: `I am interested in ${p.title}. Please contact me.` })); setShowEnquiry(true); }}><ArrowUpRight size={18}/></button></div><div className="property-content"><div className="property-type">{p.type.toUpperCase()}</div><h3>{p.title}</h3><div className="location"><MapPin size={15}/>{p.location}</div><div className="property-meta"><span><BedDouble size={15}/>{p.bhk > 0 ? `${p.bhk} BHK` : "Open plot"}</span><span><Maximize size={15}/>{Number(p.areaSqFt).toLocaleString("en-IN")} sq.ft.</span></div><div className="property-bottom"><div><small>LISTING PRICE</small><strong>{money(p.price)}</strong></div><div className="card-actions"><button title="Edit property" onClick={() => openEdit(p)}><Pencil size={16}/></button><button title="Delete property" onClick={() => deleteProperty(p)}><Trash2 size={16}/></button></div></div></div></article>)}</div> : <div className="empty-state"><Search size={30}/><strong>No properties found</strong><span>Try changing your search or filters.</span><button className="btn btn-outline" onClick={() => { setSearch(""); setTypeFilter("All"); setStatusFilter("All"); }}>Clear filters</button></div>}
      </section> : <section className="listing-section"><div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"></span> CUSTOMER RELATIONS</div><h2>Property <em>enquiries.</em></h2><p>Keep track of people interested in your listings.</p></div><button className="btn btn-dark" onClick={() => setShowEnquiry(true)}><Plus size={17}/> New enquiry</button></div>{enquiries.length ? <div className="enquiry-list">{enquiries.map((e, i) => <article className="enquiry-card" key={e._id || i}><span className="enquiry-avatar">{(e.name || "C").slice(0,1).toUpperCase()}</span><div className="enquiry-info"><strong>{e.name}</strong><span>{e.email} · {e.phone}</span><p>{e.message}</p><small>{e.propertyId?.title || "General enquiry"} · {e.createdAt ? new Date(e.createdAt).toLocaleDateString("en-IN") : "Recently added"}</small></div></article>)}</div> : <div className="empty-state"><MessageSquare size={30}/><strong>No enquiries yet</strong><span>Customer enquiries will appear here.</span><button className="btn btn-outline" onClick={() => setShowEnquiry(true)}>Add an enquiry</button></div>}</section>}

      <section className="bottom-cta"><div><div className="eyebrow"><span className="eyebrow-line"></span> LET'S GET MOVING</div><h2>Every great move<br/>starts <em>somewhere.</em></h2><p>Have a property to add or a question to ask? Start here.</p></div><div className="cta-actions"><button className="btn btn-lime" onClick={openAdd}><Plus size={17}/> Add a property</button><button className="btn btn-light-outline" onClick={() => setShowEnquiry(true)}><MessageSquare size={17}/> Contact us</button></div><span className="cta-decoration">EF</span></section>
    </main>
    <footer><a className="brand footer-brand" href="#"><span className="brand-mark"><Building2 size={20}/></span><span>estate<span className="brand-light">flow</span><small>PROPERTY MANAGEMENT</small></span></a><span>Practical No. 10 · MERN Stack Project</span><span>Built for better property management.</span></footer>

    {showForm && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setShowForm(false); }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="property-modal-title"><div className="modal-heading"><div><div className="eyebrow"><span className="eyebrow-line"></span> PROPERTY DETAILS</div><h2 id="property-modal-title">{editing ? "Edit property" : "Add a property"}</h2></div><button className="close-btn" onClick={() => setShowForm(false)} aria-label="Close"><X/></button></div><form onSubmit={saveProperty} className="form-grid" noValidate>
      <label className="full">Property title<input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="e.g. Greenview Residency"/>{errors.title && <small className="field-error">{errors.title}</small>}</label>
      <label className="full">Description<textarea rows="3" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="Describe the property and its key features"/>{errors.description && <small className="field-error">{errors.description}</small>}</label>
      <label className="full">Location<input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} placeholder="e.g. Virar West, Palghar"/>{errors.location && <small className="field-error">{errors.location}</small>}</label>
      <label>Price (₹)<input type="number" min="1" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} placeholder="4500000"/>{errors.price && <small className="field-error">{errors.price}</small>}</label>
      <label>Area (sq. ft.)<input type="number" min="1" value={form.areaSqFt} onChange={e => setForm({ ...form, areaSqFt: e.target.value })} placeholder="850"/>{errors.areaSqFt && <small className="field-error">{errors.areaSqFt}</small>}</label>
      <label>Property type<select value={form.type} onChange={e => setForm({ ...form, type: e.target.value })}><option>Apartment</option><option>Villa</option><option>Plot</option><option>Commercial</option></select></label>
      <label>BHK (0 for plot)<input type="number" min="0" max="20" value={form.bhk} onChange={e => setForm({ ...form, bhk: e.target.value })}/></label>
      <label>Status<select value={form.status} onChange={e => setForm({ ...form, status: e.target.value })}><option>Available</option><option>Under Offer</option><option>Sold</option></select></label>
      <label>Owner name<input value={form.ownerName} onChange={e => setForm({ ...form, ownerName: e.target.value })} placeholder="Optional"/></label>
      <label className="full">Image URL (optional)<input value={form.imageUrl} onChange={e => setForm({ ...form, imageUrl: e.target.value })} placeholder="https://example.com/property.jpg"/>{errors.imageUrl && <small className="field-error">{errors.imageUrl}</small>}</label>
      <div className="form-footer full"><button type="button" className="btn btn-outline" onClick={() => setShowForm(false)}>Cancel</button><button type="submit" className="btn btn-dark">{editing ? "Save changes" : "Create listing"}</button></div>
    </form></section></div>}

    {showEnquiry && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setShowEnquiry(false); }}><section className="modal enquiry-modal" role="dialog" aria-modal="true" aria-labelledby="enquiry-modal-title"><div className="modal-heading"><div><div className="eyebrow"><span className="eyebrow-line"></span> WE'RE HERE TO HELP</div><h2 id="enquiry-modal-title">Send an enquiry</h2></div><button className="close-btn" onClick={() => setShowEnquiry(false)} aria-label="Close"><X/></button></div><form onSubmit={submitEnquiry} className="form-grid" noValidate><label className="full">Full name<input required value={enquiryForm.name} onChange={e => setEnquiryForm({ ...enquiryForm, name: e.target.value })} placeholder="Your name"/></label><label>Email address<input required type="email" value={enquiryForm.email} onChange={e => setEnquiryForm({ ...enquiryForm, email: e.target.value })} placeholder="you@example.com"/></label><label>Phone number<input required value={enquiryForm.phone} onChange={e => setEnquiryForm({ ...enquiryForm, phone: e.target.value })} placeholder="Your contact number"/></label><label className="full">Interested property<select value={enquiryForm.propertyId} onChange={e => setEnquiryForm({ ...enquiryForm, propertyId: e.target.value })}><option value="">General enquiry</option>{properties.filter(p => !String(p._id).startsWith("demo")).map(p => <option key={p._id} value={p._id}>{p.title}</option>)}</select></label><label className="full">Message<textarea rows="4" required value={enquiryForm.message} onChange={e => setEnquiryForm({ ...enquiryForm, message: e.target.value })} placeholder="Tell us what you're looking for"/></label><div className="form-footer full"><button type="button" className="btn btn-outline" onClick={() => setShowEnquiry(false)}>Cancel</button><button type="submit" className="btn btn-dark">Submit enquiry</button></div></form></section></div>}
  </div>;
}
export default App;
