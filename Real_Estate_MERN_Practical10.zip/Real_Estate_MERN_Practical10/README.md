# Real Estate Property Management System (MERN)

Practical No. 10 — MERN Project

A responsive property listing and enquiry management application built with React, Node.js, Express, and MongoDB.

## Features
- View property listings with photo URL, location, price, BHK, type, and status
- Search by title/location and filter by property type
- Add, edit, and delete properties (CRUD)
- Form validation on frontend and backend
- Customer enquiry form and enquiry list
- REST API using Express
- MongoDB persistence using Mongoose
- Demo mode: frontend can run with sample data when backend is not configured

## Tech stack
- React + Vite
- Node.js + Express
- MongoDB Atlas or local MongoDB
- Mongoose
- CSS responsive layout

## Run locally (computer)
Requirements: Node.js 20+ and a MongoDB database.

### 1. Backend
```bash
cd backend
cp .env.example .env
# Set MONGODB_URI in .env
npm install
npm run dev
```
Backend runs at `http://localhost:5000`.

### 2. Frontend
Open another terminal:
```bash
cd frontend
npm install
npm run dev
```
Vite prints the local URL, usually `http://localhost:5173`.

## Mobile-only workflow
You can edit/upload files using GitHub in your mobile browser and run a Node project in a cloud IDE such as Replit or GitHub Codespaces (availability/limits may vary). For a live website, deploy the frontend and backend separately, then set the frontend `VITE_API_URL` to the deployed backend URL. Create a MongoDB Atlas cluster and set its connection string in the backend environment variables. Never put database credentials in frontend code or commit `.env`.

## Environment variables
Backend `.env`:
```env
PORT=5000
MONGODB_URI=mongodb+srv://YOUR_USER:YOUR_PASSWORD@YOUR_CLUSTER.mongodb.net/realestate?retryWrites=true&w=majority
CLIENT_ORIGIN=http://localhost:5173
```
Frontend `.env` (optional):
```env
VITE_API_URL=http://localhost:5000/api
```

## API endpoints
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | API status |
| GET | `/api/properties` | List properties; optional `search`, `type`, `status` |
| GET | `/api/properties/:id` | One property |
| POST | `/api/properties` | Create property |
| PUT | `/api/properties/:id` | Update property |
| DELETE | `/api/properties/:id` | Delete property |
| GET | `/api/enquiries` | List enquiries |
| POST | `/api/enquiries` | Create enquiry |

## Important
The included sample data is for demonstration. If the backend is offline or not configured, the frontend shows sample properties in demo mode; edits in demo mode stay in browser memory only and do not persist after refresh. For final practical demonstration, configure MongoDB and use the real API.
